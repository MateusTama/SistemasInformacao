import javax.swing.JOptionPane;

public class UsaArvoreBinaria {

    public static void main(String[] args)
    {ArvoreBinaria minha;
        String entra;
        int alt;
        entra = JOptionPane.showInputDialog("INFORME A ALTURA DA ARVORE");
        alt = Integer.parseInt(entra);
        minha = new ArvoreBinaria(alt);

        minha.carregaArvore();
        System.out.print("\nVEJA A ARVORE EM PRE-ORDEM C/ PREFERENCIA A ESQ: ");
        minha.pre_ordem(0);
        System.out.print("\nVEJA A ARVORE EM POS-ORDEM C/ PREFERENCIA A ESQ: ");
        minha.pos_ordem(0);
        System.out.print("\nVEJA A ARVORE IN-ORDEM C/ PREFERENCIA A ESQ: ");
        minha.in_ordem(0);
        System.out.print("\nVEJA A ARVORE EM PRE-ORDEM C/ PREFERENCIA A DIR: ");
        minha.pre_ordem_direita(0);
        System.out.print("\nVEJA A ARVORE EM POS-ORDEM C/ PREFERENCIA A DIR: ");
        minha.pos_ordem_direita(0);
        System.out.print("\nVEJA A ARVORE IN-ORDEM C/ PREFERENCIA A DIR: ");
        minha.in_ordem_direita(0);
    }
}