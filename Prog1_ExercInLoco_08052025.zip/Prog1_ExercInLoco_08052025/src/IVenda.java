public interface IVenda {
    public void vender();
}
