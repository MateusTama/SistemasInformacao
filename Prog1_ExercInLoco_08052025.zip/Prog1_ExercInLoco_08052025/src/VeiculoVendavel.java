public class VeiculoVendavel extends Veiculo implements IVenda {
    public VeiculoVendavel(String marca, String modelo, String ano, String cor, Double preco) {
        super(marca, modelo, ano, cor, preco);
    }

    @Override
    public void vender() {
        System.out.println("Veiculo vendido");
    }

    public int gerarCodigo() {
        int codigo = (int)(Math.random() * 101);
        return codigo;
    }

    public void atualizarEstoque() {
        System.out.println("Estoque atualizado.");
    }
}
