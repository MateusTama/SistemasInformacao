public class Main {
    public static void main(String[] args) {
        Carro focus = new Carro("Ford", "Focus", "2014", "Prata", 43500.00);
        Moto biz = new Moto("Honda", "Biz", "2015", "Branca", 8400.00);

        System.out.println();
        //Imprimir
        focus.imprimir();
        biz.imprimir();

        System.out.println();
        //Código de venda
        System.out.println("Código de venda do carro: " + focus.gerarCodigo());
        System.out.println("Código de venda da moto: " + biz.gerarCodigo());

        System.out.println();
        //Vender
        focus.vender();
        focus.atualizarEstoque();

        System.out.println();
        biz.vender();
        biz.atualizarEstoque();
    }
}