public class Moto extends VeiculoVendavel {

    public Moto(String marca, String modelo, String ano, String cor, Double preco) {
        super(marca, modelo, ano, cor, preco);
    }

    public Double calcularPreco() {
        return this.getPreco();
    }

    public void imprimir() {
        System.out.println(this.toString());
    }

    public void atualizarEstoque() {
        System.out.println("Estoque da moto atualizado.");
    }

    public int gerarCodigo() {
        int codigo = (int)(Math.random() * 101);
        return codigo;
    }
}
