public class Nodo {
    public int dado;
    public Nodo filhoEsq;
    public Nodo filhoDir;

    Nodo(int vem) {
        dado = vem;
        filhoEsq = null;
        filhoDir = null;
    }
}
