import javax.swing.JOptionPane;

public class UsaArvore {
    public static void main(String[] args) {
        ArvoreB minha;
        minha = new ArvoreB();
        minha.construir(minha.raiz, 'r', 0);

        String entra;
        int aux, opcao;
        do {
            entra = JOptionPane.showInputDialog("MENU" +
                    "\n\n\t1. PRE ORDEM ESQ.\n\t2. PRE ORDEM DIR." +
                    "\n\t3. POS ORDEM ESQ." + "\n\t4. POS ORDEM DIR." +
                    "\n\t5. IN ORDEM ESQ." + "\n\t6. IN ORDEM DIR." +
                    "\n\t9. VAZAR\n\n\tINFORME SUA OPCAO ");
            opcao = Integer.parseInt(entra);
            switch (opcao) {
                case 1:
                    if (minha.getRaiz() != null) {
                        System.out.print("\n\nMOSTRANDO A ARVORE EM PRE-ORDEM C/ PREF A ESQUERDA: ");
                        minha.varrePreOrdemEsquerda(minha.getRaiz());
                    } else
                        System.out.println("\nNADA NA ARVORE");
                    break;
                case 2:
                    if (minha.getRaiz() != null) {
                        System.out.print("\n\nMOSTRANDO A ARVORE EM PRE-ORDEM C/ PREF A DIREITA: ");
                        minha.varrePreOrdemDireita(minha.getRaiz());
                    } else
                        System.out.println("\nNADA NA ARVORE");
                    break;
                case 3:
                    if (minha.getRaiz() != null) {
                        System.out.print("\n\nMOSTRANDO A ARVORE EM POS-ORDEM C/ PREF A ESQUERDA: ");
                        minha.varrePosOrdemEsquerda(minha.getRaiz());
                    } else
                        System.out.println("\nNADA NA ARVORE");
                    break;
                case 4:
                    if (minha.getRaiz() != null) {
                        System.out.print("\n\nMOSTRANDO A ARVORE EM POS-ORDEM C/ PREF A DIREITA: ");
                        minha.varrePosOrdemDireita(minha.getRaiz());
                    } else
                        System.out.println("\nNADA NA ARVORE");
                    break;
                case 5:
                    if (minha.getRaiz() != null) {
                        System.out.print("\n\nMOSTRANDO A ARVORE EM IN-ORDEM C/ PREF A ESQUERDA: ");
                        minha.varreInOrdemEsquerda(minha.getRaiz());
                    } else
                        System.out.println("\nNADA NA ARVORE");
                    break;
                case 6:
                    if (minha.getRaiz() != null) {
                        System.out.print("\n\nMOSTRANDO A ARVORE EM IN-ORDEM C/ PREF A DIREITA: ");
                        minha.varreInOrdemDireita(minha.getRaiz());
                    } else
                        System.out.println("\nNADA NA ARVORE");
                    break;
            }
        } while (opcao != 9);

        System.out.println("\nOBRIGADO POR USAR A ÁRVORE");
    }
}
	