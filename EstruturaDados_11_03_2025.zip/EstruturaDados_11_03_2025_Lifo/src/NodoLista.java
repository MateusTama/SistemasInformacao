
public class NodoLista {
	public int idade;
	public NodoLista vizinho;
	
	NodoLista (int idade) {
		this.idade = idade;
		vizinho = null;
	}
}
