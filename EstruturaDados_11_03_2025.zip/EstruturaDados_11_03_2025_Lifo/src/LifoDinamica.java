
public class LifoDinamica {
	private NodoLista topo;
	LifoDinamica() {
		topo = null;
	} 
	
	public void push(int idade) {
		NodoLista aux;
		aux = new NodoLista(idade);
		aux.vizinho = topo;
		topo = aux;
	}
	
	public int pop() {
		//Não há elementos na lista
		if (topo == null) {
			return -999;
		}
		int idade = topo.idade;
		topo = topo.vizinho;
		return idade;
	} 
	
	public void reset() {
		topo = null;
	}
	
	public void mostrar() {
		if (topo == null) {
			return;
		}
		NodoLista aux;
		aux = topo;
		System.out.println("\nVeja a pilha:\n");
		while (aux != null) {
			System.out.println(aux.idade);
			aux = aux.vizinho;
		}
	}
	
	public int mostrarCabeca() {
		int aux = -999;
		if (topo == null) {
			return aux;
		}
		aux = topo.idade;
		return aux;
	}
}
