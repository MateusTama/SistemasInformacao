
public class Main {

	public static void main(String[] args) {
		LifoDinamica pilhaDinamica;
		pilhaDinamica = new LifoDinamica();
		
		pilhaDinamica.push(18);
		pilhaDinamica.push(20);
		pilhaDinamica.push(21);
		pilhaDinamica.push(25);
		pilhaDinamica.pop();
		System.out.println("Cabeça: " + pilhaDinamica.mostrarCabeca());
		pilhaDinamica.mostrar();
	}

}
