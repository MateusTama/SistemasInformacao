
public class Main {

	public static void main(String[] args) {
		Fifo pilhaDinamica;
		pilhaDinamica = new Fifo();
		
		pilhaDinamica.enqueue(18);
		pilhaDinamica.enqueue(20);
		pilhaDinamica.enqueue(21);
		pilhaDinamica.enqueue(25);

		pilhaDinamica.mostrar();
		//pilhaDinamica.mostrarContrario();

	}

}
