
public class Nodo {
	public int idade;
	public Nodo seguinte;
	
	Nodo(int idade) {
		this.idade = idade;
		seguinte = null;
	}
}
