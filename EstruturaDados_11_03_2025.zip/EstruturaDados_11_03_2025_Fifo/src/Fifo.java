
public class Fifo {
	private Nodo comeco;
	private Nodo fim;
	
	Fifo() {
		comeco = null;
	    fim = null;
	}
	   
	public void enqueue(int quem){
		Nodo aux;
        aux = new Nodo(quem);
        if (comeco == null)
        	comeco = aux;
        else
        	fim.seguinte = aux;
        fim = aux;
       }
  
	public void mostrar(){
		Nodo aux;
	    if (comeco == null){
		   System.out.println("NINGUEM NA FILA");
		   return;
	    } 		   
	    System.out.print("\nVEJA A LISTA FIFO: ");
	    aux = comeco;
	    while (aux != null){
		   System.out.print("  "+aux.idade);
	       aux = aux.seguinte;
	    }
	 }
	   	   
	   public int dequeue(){
		   int aux = -99;
		   if (comeco != null){
			   aux = comeco.idade;
			   comeco = comeco.seguinte;
			   if (comeco == null)
				   fim = null;
			   }
		   return aux;
		   }
	   
	   public int cabeca(){
		   if (comeco == null)
			   return -99;
		   return comeco.idade;
		   }  
	     
	   
	   public void reset(){
		   comeco = null;
		   fim = null;
		   }
	   

	   public void mostrarContrario() {
		   	Fifo ListaAux, NovaLista;
		   	ListaAux = this;
		   	NovaLista = new Fifo();
			Nodo aux, aux2;
		    if (comeco == null){
			   System.out.println("NINGUEM NA FILA");
			   return;
		    } 		 
			aux = ListaAux.comeco;
			aux2 = ListaAux.comeco.seguinte;
		    System.out.print("\nVEJA A LISTA FIFO: ");
		    while (aux != null){
		    	if (aux2 == null) {
		    		 System.out.print(aux.idade);
		    		NovaLista.enqueue(aux.idade);
		    		aux.seguinte = null;
		    		ListaAux.fim = aux;
		    		aux = ListaAux.comeco;
		    		
		    	} else {
		    		aux = aux2;
		    		aux2 = aux2.seguinte;
		    	}
		    }
		    NovaLista.mostrar();
	   }
  }  

